# 🏫 自習室 混雑・空席状況システム

感圧センサー（FSR406 + Raspberry Pi）で自習室の座席利用状況をリアルタイムに可視化し、
Supabase（PostgreSQL）に蓄積したデータから曜日ごとの空席数を予測するダッシュボードです。

## 主な機能

- **リアルタイム座席マップ**：座席1番は実機センサーと連動し「利用中 / 退席中かも / 空席」の3状態を表示
- **来週の空席予測**：曜日ごとの直近実績を最小二乗法による単回帰でトレンド予測
- **当日の空席推移グラフ**：Chart.jsで8:00〜21:00の1時間ごとの空席数を表示
- **管理者モード**：パスワード認証で過去の実績ログを検索・閲覧可能

## 構成

- **フロントエンド**: Flask + Jinja2テンプレート（`index.html`）、Chart.js
- **バックエンド**: Python（Flask）+ ソケット通信でRaspberry Piからのセンサーデータを受信
- **データベース**: [Supabase](https://supabase.com/)（PostgreSQL）
  - `daily_sensoe_log`：センサーの生ログ（受信の都度記録）
  - `daily_vacancy_status`：1時間ごとの空席集計（予測・管理者ログ画面が参照）

## 使用技術・ライブラリ

- **Python / Flask** — Webサーバー・ルーティング
- **psycopg2** — PostgreSQL（Supabase）への接続
- **socket / threading** — Raspberry Piからのセンサーデータ受信（別スレッドで常駐）
- **zoneinfo** — タイムゾーン変換（Asia/Tokyo）
- **Supabase** — PostgreSQLデータベース（センサーログ・空席集計の保存先）
- **Chart.js**（CDN読み込み）— 空席推移グラフの描画
- **Jinja2**（Flask同梱）— HTMLテンプレートレンダリング
- **Raspberry Pi + FSR406（感圧センサー）** — 実機の座席利用検知

## セットアップ

### 1. リポジトリの取得

```bash
git clone <このリポジトリのURL>
cd <リポジトリ名>
pip install flask psycopg2-binary
```

### 2. Supabaseプロジェクトの準備

1. [Supabase](https://supabase.com/) で新規プロジェクトを作成
2. `daily_vacancy_status` テーブルを作成（`daily_sensoe_log` はアプリ起動時に自動作成されます）

```sql
CREATE TABLE daily_vacancy_status (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    time timestamp with time zone NOT NULL,
    target_week text,
    day_of_week text,
    predicted_vacancy integer
);
```

3. プロジェクトの Settings → Database から接続情報（host / port / user / password）を確認

### 3. 設定値の入力

`app.py` 冒頭の以下の項目を、自分のSupabaseプロジェクトの値に書き換えてください。

```python
ADMIN_PASSWORD = "自己設定"  # 好きな管理者パスワードに変更

DB_CONFIG = {
    "host": "自己設定",      # Supabase Settings → Database の Host
    "port": 0000,            # 例: 5432
    "database": "自己設定",  # 例: postgres
    "user": "自己設定",      # 例: postgres
    "password": "自己設定",  # Supabaseの接続パスワード
    "sslmode": "自己設定",   # 例: require
}

app.secret_key = "個人設定"  # 好きな文字列に変更（第三者に推測されない値を推奨）
```

⚠️ **書き換えた後の`app.py`は絶対にpushしないでください。**
このリポジトリで公開されているのはあくまで「自己設定」のプレースホルダーのままのテンプレートです。
実際の値を入れたファイルを誤ってコミットしないよう、以下のいずれかの対策を推奨します。

- 書き換え後は `git update-index --assume-unchanged app.py` でGitに変更を追跡させない
- もしくは `app.py` を `app.local.py` などにコピーして、そちらで運用する（`.gitignore`に追加）

### 4. 起動

```bash
python app.py
```

- Webダッシュボード: `http://localhost:5001`
- センサー受信用ソケットサーバー: `0.0.0.0:8765`（Raspberry Pi側からJSON形式で `{"id": ..., "force": ...}` を送信）

## ディレクトリ構成

```
.
├── app.py              # Flaskアプリ本体（ルーティング・DB処理・ソケット通信）
└── templates/
    └── index.html      # ダッシュボード画面
```

## ライセンス

MIT License（必要に応じて変更してください）
